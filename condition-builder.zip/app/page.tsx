import ConditionBuilder from "@/components/condition-builder"

export default function Home() {
  return (
    <main className="container mx-auto py-10 px-4">
      <h1 className="text-3xl font-bold mb-6">Parameter Condition Builder</h1>
      <p className="text-gray-600 mb-8">
        Create complex parameter conditions with AND/OR logic and nested condition groups.
      </p>
      <ConditionBuilder />
    </main>
  )
}
