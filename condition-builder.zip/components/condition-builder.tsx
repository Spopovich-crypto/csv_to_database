"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { PlusCircle } from "lucide-react"
import ConditionGroup from "@/components/condition-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export type Condition = {
  id: string
  parameter: string
  operator: string
  value: string
}

export type ConditionGroupType = {
  id: string
  type: "AND" | "OR"
  conditions: Condition[]
  groups: ConditionGroupType[]
}

export default function ConditionBuilder() {
  const [rootGroup, setRootGroup] = useState<ConditionGroupType>({
    id: "root",
    type: "AND",
    conditions: [],
    groups: [],
  })

  const [result, setResult] = useState<string>("")

  const handleAddGroup = () => {
    const newGroup: ConditionGroupType = {
      id: `group-${Date.now()}`,
      type: "AND",
      conditions: [],
      groups: [],
    }

    setRootGroup({
      ...rootGroup,
      groups: [...rootGroup.groups, newGroup],
    })
  }

  const handleUpdateGroup = (updatedGroup: ConditionGroupType) => {
    setRootGroup(updatedGroup)
  }

  const handleGenerateResult = () => {
    const resultString = JSON.stringify(rootGroup, null, 2)
    setResult(resultString)
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-semibold">Root Condition Group</h2>
              <Select
                value={rootGroup.type}
                onValueChange={(value) => setRootGroup({ ...rootGroup, type: value as "AND" | "OR" })}
              >
                <SelectTrigger className="w-24">
                  <SelectValue placeholder="Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="AND">AND</SelectItem>
                  <SelectItem value="OR">OR</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button variant="outline" onClick={handleAddGroup}>
              <PlusCircle className="h-4 w-4 mr-2" />
              Add Group
            </Button>
          </div>

          <ConditionGroup group={rootGroup} onUpdate={handleUpdateGroup} isRoot={true} />

          <div className="mt-6">
            <Button onClick={handleGenerateResult}>Generate Condition JSON</Button>
          </div>
        </CardContent>
      </Card>

      {result && (
        <Card>
          <CardContent className="pt-6">
            <h2 className="text-xl font-semibold mb-4">Generated Condition Structure</h2>
            <pre className="bg-gray-100 p-4 rounded-md overflow-auto max-h-96">{result}</pre>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
