"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { PlusCircle, Trash2, ChevronDown, ChevronUp } from "lucide-react"
import type { ConditionGroupType, Condition } from "@/components/condition-builder"

interface ConditionGroupProps {
  group: ConditionGroupType
  onUpdate: (group: ConditionGroupType) => void
  onRemove?: () => void
  isRoot?: boolean
}

export default function ConditionGroup({ group, onUpdate, onRemove, isRoot = false }: ConditionGroupProps) {
  const [collapsed, setCollapsed] = useState(false)

  const handleAddCondition = () => {
    const newCondition: Condition = {
      id: `condition-${Date.now()}`,
      parameter: "",
      operator: "equals",
      value: "",
    }

    onUpdate({
      ...group,
      conditions: [...group.conditions, newCondition],
    })
  }

  const handleAddGroup = () => {
    const newGroup: ConditionGroupType = {
      id: `group-${Date.now()}`,
      type: "AND",
      conditions: [],
      groups: [],
    }

    onUpdate({
      ...group,
      groups: [...group.groups, newGroup],
    })
  }

  const handleUpdateCondition = (updatedCondition: Condition) => {
    const updatedConditions = group.conditions.map((condition) =>
      condition.id === updatedCondition.id ? updatedCondition : condition,
    )

    onUpdate({
      ...group,
      conditions: updatedConditions,
    })
  }

  const handleRemoveCondition = (conditionId: string) => {
    onUpdate({
      ...group,
      conditions: group.conditions.filter((c) => c.id !== conditionId),
    })
  }

  const handleUpdateNestedGroup = (updatedGroup: ConditionGroupType) => {
    const updatedGroups = group.groups.map((g) => (g.id === updatedGroup.id ? updatedGroup : g))

    onUpdate({
      ...group,
      groups: updatedGroups,
    })
  }

  const handleRemoveNestedGroup = (groupId: string) => {
    onUpdate({
      ...group,
      groups: group.groups.filter((g) => g.id !== groupId),
    })
  }

  return (
    <div className="border rounded-md p-4 mb-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" onClick={() => setCollapsed(!collapsed)} className="p-1 h-8 w-8">
            {collapsed ? <ChevronDown className="h-4 w-4" /> : <ChevronUp className="h-4 w-4" />}
          </Button>

          <Select value={group.type} onValueChange={(value) => onUpdate({ ...group, type: value as "AND" | "OR" })}>
            <SelectTrigger className="w-24">
              <SelectValue placeholder="Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="AND">AND</SelectItem>
              <SelectItem value="OR">OR</SelectItem>
            </SelectContent>
          </Select>

          {!isRoot && (
            <Button variant="destructive" size="sm" onClick={onRemove}>
              <Trash2 className="h-4 w-4" />
            </Button>
          )}
        </div>

        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={handleAddCondition}>
            <PlusCircle className="h-4 w-4 mr-1" />
            Add Condition
          </Button>
          <Button variant="outline" size="sm" onClick={handleAddGroup}>
            <PlusCircle className="h-4 w-4 mr-1" />
            Add Group
          </Button>
        </div>
      </div>

      {!collapsed && (
        <>
          {group.conditions.length > 0 && (
            <div className="space-y-3 mb-4">
              {group.conditions.map((condition) => (
                <div key={condition.id} className="flex items-center gap-2">
                  <Input
                    placeholder="Parameter"
                    value={condition.parameter}
                    onChange={(e) =>
                      handleUpdateCondition({
                        ...condition,
                        parameter: e.target.value,
                      })
                    }
                    className="flex-1"
                  />

                  <Select
                    value={condition.operator}
                    onValueChange={(value) =>
                      handleUpdateCondition({
                        ...condition,
                        operator: value,
                      })
                    }
                  >
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="Operator" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="equals">Equals</SelectItem>
                      <SelectItem value="not_equals">Not Equals</SelectItem>
                      <SelectItem value="contains">Contains</SelectItem>
                      <SelectItem value="starts_with">Starts With</SelectItem>
                      <SelectItem value="ends_with">Ends With</SelectItem>
                      <SelectItem value="greater_than">Greater Than</SelectItem>
                      <SelectItem value="less_than">Less Than</SelectItem>
                    </SelectContent>
                  </Select>

                  <Input
                    placeholder="Value"
                    value={condition.value}
                    onChange={(e) =>
                      handleUpdateCondition({
                        ...condition,
                        value: e.target.value,
                      })
                    }
                    className="flex-1"
                  />

                  <Button variant="destructive" size="sm" onClick={() => handleRemoveCondition(condition.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}

          {group.groups.map((nestedGroup) => (
            <ConditionGroup
              key={nestedGroup.id}
              group={nestedGroup}
              onUpdate={handleUpdateNestedGroup}
              onRemove={() => handleRemoveNestedGroup(nestedGroup.id)}
            />
          ))}
        </>
      )}
    </div>
  )
}
